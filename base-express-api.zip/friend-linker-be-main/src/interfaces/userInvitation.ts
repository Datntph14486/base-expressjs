export enum UserInvationStatus {
    Pending = "pending",
    Reject = "reject",
}
