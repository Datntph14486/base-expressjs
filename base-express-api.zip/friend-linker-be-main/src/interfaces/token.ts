export enum TokenTypes {
    Refresh = "refresh",
    Access = "access",
}
