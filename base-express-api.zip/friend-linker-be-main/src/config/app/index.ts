const app = {
    port: process.env.PORT,
};

export default app;
